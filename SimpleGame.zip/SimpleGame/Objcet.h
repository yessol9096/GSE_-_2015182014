#pragma once
#include "Renderer.h"

class Renderer;

class Objcet
{
private:
	// ������Ʈ ��ġ
	float position_x;
	float position_y;
	float position_z;
	// ������Ʈ ũ��
	float fixel_size;

	float red;
	float green;
	float blue;
	float transparent;

public:
	Objcet();
	virtual ~Objcet();

	virtual void Object(float x, float y, float z, float size, float r, float g, float b, float a);
};

