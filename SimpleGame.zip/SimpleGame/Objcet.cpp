#include "stdafx.h"
#include "Renderer.h"
#include "Objcet.h"

Renderer *m_pRender;

Objcet::Objcet()
{
}


Objcet::~Objcet()
{
}


void Objcet::Object(float x, float y, float z, float size, float r, float g, float b, float a)
{
	position_x = x;
	position_y = y;
	position_z = z;

	fixel_size = size;
	red = r;
	green = g;
	blue = b;
	transparent = a;

	m_pRender = new Renderer(500, 500);
	m_pRender->DrawSolidRect(position_x, position_y, position_z, size, red, green, blue, transparent);
}



