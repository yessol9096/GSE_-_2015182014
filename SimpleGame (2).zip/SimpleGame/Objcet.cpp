#include "stdafx.h"
#include "Objcet.h"
#include "Renderer.h"


void Objcet::drawObject(float p_x, float p_y, float p_z, float size)
{
	position_x = p_x;
	position_y = p_y;
	position_z = p_z;

	fixel_size = size;

}



